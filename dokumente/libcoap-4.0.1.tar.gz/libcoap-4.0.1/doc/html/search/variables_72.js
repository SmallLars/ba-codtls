var searchData=
[
  ['ready',['ready',['../client_8c.html#a4adb4fb035eed17910c98225be64ec83',1,'client.c']]],
  ['recvqueue',['recvqueue',['../structcoap__context__t.html#a6230687bf6b5bd5c214bbfb908ff6fa5',1,'coap_context_t']]],
  ['remote',['remote',['../structcoap__queue__t.html#a15ba08baabdadfe7ec9179e7dba5b5f2',1,'coap_queue_t']]],
  ['resource',['resource',['../coap-observer_8c.html#add13bccf3a03ea896a093ee3634a7428',1,'coap-observer.c']]],
  ['resource_5fkey',['resource_key',['../structcoap__payload__t.html#a85bf44b76aa2c9c123c4ab9b0003c22a',1,'coap_payload_t::resource_key()'],['../structcoap__dynamic__uri__t.html#a1532fe3a9ac6117beda5b882073462d6',1,'coap_dynamic_uri_t::resource_key()']]],
  ['resources',['resources',['../structcoap__context__t.html#aaf441070f9b1f2aea225fc61b60a6bb8',1,'coap_context_t::resources()'],['../rd_8c.html#a6a74f818cd18d9dc8491c3d3afb5ffba',1,'resources():&#160;rd.c']]],
  ['response_5fhandler',['response_handler',['../structcoap__context__t.html#aaeae5156b5641ce3a0bb6d13f5c226d2',1,'coap_context_t']]],
  ['retransmit_5fcnt',['retransmit_cnt',['../structcoap__queue__t.html#aff24f5a43b3d2182535bc7bd2b5f5341',1,'coap_queue_t']]]
];
