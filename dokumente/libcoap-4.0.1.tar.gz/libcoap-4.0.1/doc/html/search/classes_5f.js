var searchData=
[
  ['_5f_5fcoap_5faddress_5ft',['__coap_address_t',['../struct____coap__address__t.html',1,'']]]
];
