var searchData=
[
  ['rd_5fdelete',['rd_delete',['../rd_8c.html#abaa86756a13f6d7a92ec81544613c9e6',1,'rd.c']]],
  ['rd_5fnew',['rd_new',['../rd_8c.html#aa07a4771cea2265ed6afc6b2ede50b0b',1,'rd.c']]],
  ['resolve_5faddress',['resolve_address',['../client_8c.html#a109f4a0f5a7e52ff35bc7929210afcf5',1,'client.c']]]
];
