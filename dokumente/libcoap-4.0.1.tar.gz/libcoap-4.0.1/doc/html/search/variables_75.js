var searchData=
[
  ['uri',['uri',['../structcoap__resource__t.html#aa250947f8ad4cf5e4ebe60ea305c4607',1,'coap_resource_t::uri()'],['../client_8c.html#a7de121932f993685d72a3990ea07480b',1,'uri():&#160;client.c']]]
];
