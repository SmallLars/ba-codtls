var searchData=
[
  ['segment_5fhandler_5ft',['segment_handler_t',['../uri_8c.html#a94eef80cd10d634b5e9f9004df8d439a',1,'uri.c']]]
];
